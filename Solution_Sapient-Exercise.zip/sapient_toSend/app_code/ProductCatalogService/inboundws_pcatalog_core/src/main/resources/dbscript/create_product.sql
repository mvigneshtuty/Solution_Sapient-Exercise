CREATE TABLE products (
  id         INTEGER auto_increment PRIMARY KEY,
  product VARCHAR(50),
  category  VARCHAR(30)
);