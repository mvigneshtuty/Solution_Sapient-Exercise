package org.nfjs.springws.pcatalog.util;

public class PCatalogUtil {
	public static final String add = "ADD";
	public static final String del = "DELETE";
	public static final String get = "GET";
	public static final String err = "ERROR";
	public static final String errCode = "500";
}
