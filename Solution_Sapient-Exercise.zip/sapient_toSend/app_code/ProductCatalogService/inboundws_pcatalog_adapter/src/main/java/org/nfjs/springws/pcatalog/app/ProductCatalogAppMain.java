package org.nfjs.springws.pcatalog.app;

public class ProductCatalogAppMain {

	public static void main(String[] args) {
	//TODO	
	}

}
