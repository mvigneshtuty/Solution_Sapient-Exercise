CREATE TABLE price (
  id         INTEGER auto_increment PRIMARY KEY,
  product VARCHAR(50),
  price  VARCHAR(10)
);